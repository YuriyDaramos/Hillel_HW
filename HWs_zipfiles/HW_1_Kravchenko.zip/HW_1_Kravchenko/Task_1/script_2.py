string = "This is apple"
print(string.upper())